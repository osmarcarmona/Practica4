/****************************************************************************
 * Project developed as a simple Blink the LED's to 
 * demonstrate basic CodeWarrior functionality and capability.
 * Borrowed from Freedom Example Projects: Blinky
 * 
 * Date: 11 Sept 2012
 * Author: M. Ruthenbeck
 * Revision Level 1.0
 */

#include "derivative.h" /* include peripheral declarations */
#include "mcl\CrystalClock.h"
#include "mcl\ARM_SysTick.h"
#include "gsc_scheduler\gsc_sch_core\gsc_sch_core_intf.h"
#include "main.h"
#include "mcg.h"
#include "gpio.h"
#include "uart.h"
#include "io.h"
#include "nvic.h"
#include "libs.h"
#include <stdio.h>
#include <stdlib.h>
#define CONST_ID 200
#define CONST_SONG 3

volatile unsigned int sys_tick_counter = 0;

void WatchDog_cfg(void);
void uart_test(void);
//osmi
void manager_main( char ID, char FUNC, char CHECKSUM);
void check_transition(int transition, char ID, char FUNC,char CHECKSUM);
int get_transition();
void int_to_bin_digit(unsigned int in, int count, int* out);

//State 2
void check_byte_two(char FUNC);

int check_cmd();
void check_FbWb();
void check_play();

void check_equ();
int check_freq();
int check_lvl();

void check_album();
int check_actual();
int check_set();

//State 3
void check_third_byte(int ID, int FUNC,int CHECKSUM);

void print(char * msj);
int matriz[6][6]=

/*1*/{{ -1, 0, -1, -1, 3, -1},
/*2*/ { -1, -1, 1, -1, 3, -1},
/*3*/ { -1, -1, -1, 2, 5, -1},
/*4*/ { 4, 4, 6, 7, 8, -1},
/*5*/ { 4, 4, 6, 9, 8, -1},
/*6*/ { 0, 0, 1, 7, 8, -1}
};

int current_state=1;
int last_state=1;
int next_state = 2;
int FwBw_flag = 0;
int play_flag = 0;
int ID_type = -1;

    char ID_CMD= '&';
    char ID_EQU = 'f';
    char ID_ALBUM = 'D';
    char ID_MSJ =0;
    char FUNC=0;
    char SC=0;
    int digit[8];
    int album=1;
    int track=1;
    int next_album=0;

/********************************************************************/
int main (void)
{
	//int i=0;
	
	/* Disable Watch Dog */
	WatchDog_cfg();
	/* initialize clock system for 48 MHz */
	InitClock(); 
	/* Configure the timer and the interrupt to be used to generate the tick of the scheduler */
	InitSysTick();
	/* Scheduler Initialization and tasks initialization  */
	gsc_sch_core_Init();
	/* Execute Scheduler */
	gsc_sch_core_exec();
	

	return 0;
}


/*UART test*/
void uart_test(void)
{
/*#if UART_MODE == INTERRUPT

	int counter = 0;
	
	put("\r\nHello World! UART Lab using Interrupt mode\r\n");
	
	EnableInterrupts;
	enable_irq(INT_UART0 -16);
	set_irq_priority((INT_UART0 -16), 2);
	
	while(TRUE)
	{
		counter++;
		if(counter >= DLY)
		{
			GREEN_TOGGLE;
			counter = 0;
		}
	}
#else*/	
	//Polling mode
	char a,b,c,ch, mask_cmd=0x70, val;
	//static int counter = 0; 
	
	//put("\r\nHello World! UART Lab using Polling mode\r\n");
	 
		ID_MSJ = in_char();
		//ch = in_char();
		FUNC = in_char();
		//ch = in_char();
		SC = in_char();
		//ch = in_char();
		
		//out_char(0xF ^ 0xF);
		out_char(ID_MSJ);
		out_char(FUNC);
		out_char(SC);
        //print("hola");
		manager_main(ID_MSJ, FUNC,SC);
		
}

void print(char *msj){
	int i=0;
	
	out_char('\n');
	while (msj[i] != '\0') {
		out_char(msj[i++]);
	}
}

int get_transition(){
	return matriz[current_state-1][next_state-1];
}

void int_to_bin_digit(unsigned int in, int count, int* out){
    unsigned int mask = 1U << (count-1);
    int i;
    for (i = 0; i < count; i++) {
        out[i] = (in & mask) ? 1 : 0;
        in <<= 1;
    }
}

void check_transition(int transition, char ID, char FUNC,char CHECKSUM){
    int i;
    switch(transition){
        case 0:
        //print("1-2");

        i= CONST_ID - ID;

        if( 162 == i ){
           // printf(" CMD \n");
            ID_type = 0;
            print("CMD");
        }else if(98 == i){
            //printf(" EQU \n");
        	print("EQU");
            ID_type = 1;
        }else if( 132 == i){
            //printf(" ALBUM, \n");
        	print("ALM");
            ID_type = 2;
        }else{
            //printf(" ERROR DE ID \n");
        }
    
        current_state = 2;
        next_state = 3;
        break;


        case 1:
           // printf("Segundo byte\n");
           check_byte_two(FUNC);

           
           current_state = 3;
           next_state = 4;

        break;

        case 2:
          //print("Checksum");
           check_third_byte( (int)ID,(int)FUNC,(int)CHECKSUM );
           
           current_state = 1;
           next_state = 2;
         
        break;
    }
}

void check_third_byte(int ID, int FUNC,int CHECKSUM){
 //ID=25;
 //FUNC=122;
	 unsigned int mask = 1U << (7);
	 int i;
	 int xor_array[8];
	 int checksum_array[8];

   
    int xor =ID ^ FUNC;
    
 
    if( CHECKSUM == xor){
           print("CheckSum OK");
       }else{
           print("CheckSum FAIL");
       }


   
/*    out_char('\n');
    print("06");
      for (i = 0; i < 8; i++) {
          xor_array[i] = (FUNC & mask) ? 1 : 0;
          FUNC <<= 1;
          
      }
      out_char('o');
      for (i = 0; i < 8; i++) {
      out_char((int)xor_array[i]);
      } */
     

}

void check_byte_two(char FUNC){
    int_to_bin_digit((int)FUNC,8,digit);

   switch( ID_type ){

        case 0:
             cmd_main();
             break;

        case 1:
          check_equ();
            break;

        case 2:
            check_album();
            break;
        default: print("Error");

    }

}

void check_album(){
	print("Album ");
//	out_char(album);
	int o=0;

	int bin;
		int i=0;
		for (bin = 0, i = 0; i < 4; ++i )
		{
		    bin *= 2;
		    bin = bin + digit[i];
		}
		if(bin<=15){
			next_album=bin;
			album= bin;
			out_char(bin+48);
		}else{
			print("mayor que 15");
		}
		
	
	
	
 if( check_set() ){
	 print("Next Album ");
	 out_char(next_album+48);
	
 }else{
	 print("Album error");
 }
    
}

int check_set(){
	int result=1;
	int bin;
	int i=0;
	for (bin = 0, i = 4; i < 8; ++i )
	{
	    bin *= 2;
	    bin = bin + digit[i];
	}
	if(bin<=15){
		next_album=bin;
		album= bin;
		return 1;
	}else{
		return 0;
	}

}
void check_equ(){
int f=0;
int a[8];
	 for (f = 0; f < 8; f++) {
	         	// out_char(digit[i]);
	    	 int d=digit[f];
	         	 a[f]=d;
	          }
	
    if( check_freq() ){
        if( !check_lvl() ){
            print("Error LVL\n");
        }
    }else{//freq
        print("Error Freq\n");
    }
}

int check_lvl(){
    int result = 1;
     if(  1 == digit[5] ){
        print("Aumenta dB");

    }else if(  0 == digit[5] ){
        print("Disminuye dB");

    }else{
        result = 0;
    }
    return result;
}

int check_freq(){
     int result = 0;
     int f=0;
     int a[8];
     
     
     for (f = 0; f < 8; f++) {
         	// out_char(digit[i]);
    	 int d=digit[f];
         	 a[f]=d;
          }
         
     int gg=0;
     if( ( a[7] == 0 ) && ( a[6] == 0 ) ){
        print("Agudos");
        result=1;

    }else if( ( a[7] == 1 ) && ( a[6] == 0 ) ){
        print("Medios");
        result=1;

    }else if( ( a[7] == 1 ) && ( a[6] == 1 ) ){
        print("Bajos");
        result=1;

    }/*else{
        result = 0;

    }*/
    return result;
}

void cmd_main(){
     if( 0 == digit[0]  ){
        if( check_cmd() ){

                if( FwBw_flag ){
                   check_FwBw();
                    FwBw_flag = 0;
                }//fwbw flag

                if( play_flag ){
                    check_play();
                    play_flag = 0;
                }//play flag

        }else{//if check_cmd
             print("CMD error");
        }

    }else{//if 0 == digit
         print("1!=0");
    }
}

int check_cmd(){
    int result=1;

    if( ( digit[7] == 0 ) && ( digit[6] == 0 ) && ( digit[5] == 0 )){
        print("Play");
        play_flag = 1;

    }else if( ( digit[7] == 1 ) && ( digit[6] == 0 ) && ( digit[5] == 0 ) ){
        print("Pause");
        play_flag=0;

    }else if( ( digit[7] == 0 ) && ( digit[6] == 1 ) && ( digit[5] == 0 ) ){
        print("Stop");
        track=0;
        if(play_flag ==1){
        	play_flag=1;
        }else{
        	track=0;
        }

    }else if( ( digit[7] == 1 ) && ( digit[6] == 1 ) && ( digit[5] == 0 ) ){
        print("FW");
        
        FwBw_flag = 1;
        

    }else if( ( digit[7] == 0 ) && ( digit[6] == 0 ) && ( digit[5] == 1 ) ){
        print("BW");        
        FwBw_flag = 1;

    }else if( ( digit[7] == 1 ) && ( digit[6] == 0 ) && ( digit[5] == 1 ) ){
        print("Skip to ");
        out_char(++track+48);

    }else if( ( digit[7] == 0 ) && ( digit[6] == 1 ) && ( digit[5] == 1 ) ){
        print("Prev to ");
        out_char(--track+48);

    }else if( ( digit[7] == 1 ) && ( digit[6] == 1 ) && ( digit[5] == 1 ) ){
        print("Reserved");

    }else{
        print("Error");
      result= 0;
    }
    return result;
}

void check_FwBw(){

     if( ( digit[4] == 0 ) && ( digit[3] == 0 ) ){
        print("100ms");

    }else  if( ( digit[4] == 1 ) && ( digit[3] == 0 ) ){
        print("50ms");

    }else if( ( digit[4] == 0 ) && ( digit[3] == 1 ) ){
        print("20ms");

    }else if( ( digit[4] == 1 ) && ( digit[3] == 1 ) ){
        print("400ms");

    }else{
        print("Error FWBW");
    }
}

void check_play(){

     if( ( digit[5] == 0 ) && ( digit[6] == 0 ) ){
        print("500ms");

    }else if( ( digit[5] == 1 ) && ( digit[6] == 0 ) ){
        print("200ms");

    }else if( ( digit[5] == 0 ) && ( digit[6] == 1 ) ){
        print("10ms");

    }else if( ( digit[5] == 1 ) && ( digit[6] == 1 ) ){
        print("1s");

    }else{
        print("Error PLAY");
    }
}

void manager_main(char ID, char FUNC, char CHECKSUM){

  
    check_transition(get_transition(), ID, FUNC, CHECKSUM);
    check_transition(get_transition(), ID, FUNC, CHECKSUM);
    check_transition(get_transition(), ID, FUNC, CHECKSUM);

}

 
 /*
  * Init watch dog
  */
 void WatchDog_cfg(void)
 {
	 /* Disable watch dog */
	 SIM_COPC |= SIM_COPC_COPT(0);
 }
 
 void SysTick_Handler(void)
 {
 	sys_tick_counter++;
 	gsc_sch_core_tick_isr();
 }


 
