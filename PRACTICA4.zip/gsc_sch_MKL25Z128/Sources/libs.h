/*
 * libs.h
 *
 *  Created on: Jul 15, 2013
 *      Author: B34443
 */

#ifndef LIBS_H_
#define LIBS_H_

extern void put(char *ptr_str);

#endif /* LIBS_H_ */
