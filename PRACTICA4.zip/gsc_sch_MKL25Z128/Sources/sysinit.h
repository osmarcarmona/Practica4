/*
 * sysinit.h
 *
 *  Created on: May 27, 2013
 *      Author: B34443
 */

#ifndef SYSINIT_H_
#define SYSINIT_H_

extern void sysinit(void);

#endif /* SYSINIT_H_ */
